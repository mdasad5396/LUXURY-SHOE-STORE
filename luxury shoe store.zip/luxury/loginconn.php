<?php 
// start session

// connect to the database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "store";
$conn = mysqli_connect($host, $username, $password, $dbname);

// check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// get form data
$email=$_POST['email'];
$pass=$_POST['pass'];


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit();
}

// query database for user
$stmt = mysqli_prepare($conn, "SELECT  * FROM userdata WHERE email = ? ");
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    if (password_verify($pass, $row['pass'])) {
        // create session
        // $_SESSION['email'] = $row['email'];
        // $_SESSION['password'] = $row['pass'];
        
        header("Location: home.php");
    } else {
        echo '<script> alert ("incorrect"); document.location="index.php"</script>';
    }
} else {
    echo '<script> alert ("user not found"); document.location="index.php"</script>';
}

// close database connection
mysqli_close($conn);




?>