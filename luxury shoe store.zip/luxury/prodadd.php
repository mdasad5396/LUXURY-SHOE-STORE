<?php

$host ="localhost";
$username="root";
$password="";
$dbname="store";
$conn= mysqli_connect($host,$username,$password,$dbname);
if ($conn) {
    echo "successfully";
}

else{
    echo "error";
}

$title = $_GET['prod_title'];
$prize = $_GET['prod_price'];
$img = $_GET['prod_img'];

$db = "INSERT INTO products (prod_title,prod_price,prod_img) VALUES ('$title','$prize','$img')";
$result=mysqli_query($conn,$db);


if($db->num_rows > 0){
    while($row = $db->fetch_assoc()){
        $imageURL = 'images/'.$row["file_name"];
    }
}

echo ' <script> alert("Successfully Upload"); document.location="admin.php"</script>';

  

?>