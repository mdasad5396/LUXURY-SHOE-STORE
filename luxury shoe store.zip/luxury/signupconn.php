<?php
// connect to the database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "store";
$conn = mysqli_connect($host, $username, $password, $dbname);

// check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// get form data
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$password = $_POST['pass'];

// validate form data
if (empty($fname) || empty($lname) || empty($phone) || empty($email) || empty($password)) {
    echo "All fields are required";
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit();
}

if (strlen($password) >= 10) {
    echo "Password must be at least 8 characters long";
    exit();
}

// hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// insert user information into the database
$sql = "INSERT INTO userdata (fname, lname, phone, email, pass) VALUES ('$fname', '$lname' , '$phone' , '$email', '$hashed_password')";

if (mysqli_query($conn, $sql)) {
    echo '<script> alert ("successfully signup"); document.location="index.php"</script>';
} else {
    echo "Error: " . mysqli_error($conn);
}

// close database connection
mysqli_close($conn);
?>