<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags --> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <!-- Load an icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <title>LUXURY SHOE STORE</title>

  <style>
body
{
  background-color: rgb(202, 188, 188);
  overflow-x: hidden;
  height: 100%;
}
 

.content
{
  min-height: 600px;
}

.banner-image
{
 margin-bottom: 20px;
 text-align: center;
 color: #f8f8f8;
 background: url(image_name) no-repeat center;
 
 background-size: initial;
 float:inherit;
}


.button
{
    background-color: rgb(207, 57, 57);
    text-decoration-color:rgba(0, 0, 0, 0.7);
}

.hero-image {
  /* Use "linear-gradient" to add a darken background effect to the image (photographer.jpg). This will make the text easier to read */
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("photographer.jpg");

  /* Set a specific height */
  height: 50%;

  /* Position and center the image to scale nicely on all screens */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}


/* Container holding the image and the text */
.container {
  position: relative;
}

/* Place text in the middle of the image */
.text-block {
text-align: center;
position: absolute;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
color: white;
padding-top: 2%;
padding-bottom: 2%;
padding-left: 13%;
padding-right: 13%;
overflow:hidden;
margin-bottom: 12%;
background-color: rgba(0, 0, 0, 0.7);

}


#image1{
  float:left;
  padding: 0px 20px 20px 20px;
  overflow:auto;
  max-width: 280px;
 max-height: 250px;
}


.mynavbar{
        text-align:center;
        color:white;
        background-color:black;
        margin: 23px;
        padding:23px;
    }





  </style>
</head>

  <body>
   
  
  <!--Login Page for admin -->


    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="LoginModalLabel">Admin Login LUXURY SHOE STORE</h4>
        <div class="modal-body">
          <form action="adminconn.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Email address</label>
              <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
          
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input type="password" class="form-control" name="pass" id="exampleInputPassword1">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
          </form>

        </div>
      </div>
    </div>
  </div>
  </div>

 

</body>
</html>